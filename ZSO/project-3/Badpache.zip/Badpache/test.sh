echo 'This is stdout'
sleep 15
echo 'This is stderr' 1>&2
